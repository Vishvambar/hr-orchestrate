# Evaluation Report — Multi-Modal Evidence Review

Auto-generated summary from the latest run. Update manually if you want more narrative detail before submission.

## 1. System summary

- Primary provider actually used: groq_llama
- Successful providers: groq_llama, github_models
- Images as primary evidence: yes
- User history used only for risk context: yes
- Evidence requirements used in decisioning: yes

## 2. Evaluation data

- Sample CSV path: ../dataset/sample_claims.csv
- Number of rows processed in this run: 44
- Number of images processed in this run: 49
- Any rows without usable images: 1

## 3. Field-level quality

No labeled sample evaluation was available for this run.

## 4. Operational analysis

- Approximate number of model calls in this run: 31
- Approximate input tokens observed or estimated: 84725
- Approximate output tokens observed or estimated: 4046
- Number of images processed: 49
- Approximate runtime: 638.66 seconds
- Provider attempts by name: {
  "gemini": 2,
  "github_models": 2,
  "groq_llama": 25,
  "groq_qwen": 1,
  "openrouter": 1
}
- Approximate cost for this run: $0.2523, assuming $2.50/1M input tokens and $10.00/1M output tokens. Actual cash cost may be $0 when the run stays within provider free quota.
- TPM/RPM considerations: sequential calls, row delay, bounded provider cycles, and no parallel fan-out to avoid free-tier spikes.
- Batching / throttling / caching / retry strategy: one multimodal review call per row, sequential provider failover, per-row checkpointing, resume-from-output, bounded cooldown, and conservative fallback.

## 5. Final decision notes

- Why this architecture was chosen: image-first prompt with deterministic post-processing and provider failover.
- What tradeoff was intentionally made: reliability and schema control were prioritized over aggressive parallelism.
- What would be improved with more time: task-specific image adjudication and richer per-field calibration.
